<?php
session_start();
include 'reset_sessions.php';
header("Location:../index.php");
?>
