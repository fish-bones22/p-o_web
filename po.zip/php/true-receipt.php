<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
      <div class="container">
        <div class="form-group">
          <h3>P&amp;O Transport Corp.</h3>
          <p><strong>True Receipt</strong></p>
        </div>
          <div class="container">
            <div><label for="Receipt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Receipt Number:&nbsp;</label>
            <span> <input type="hidden" id="Receipt" class="form-control"></span></div>
            <div><label for="Bus">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bus Number:&nbsp;</label>
            <span> <input type="hidden" id="Bus" class="form-control"></span></div>
            <div><label for="name">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name:&nbsp;</label>
            <span> <input type="hidden" id="name"></span></div>
            <div><label for="Cnumber">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Contact Number:&nbsp;</label>
            <span> <input type="hidden" id="Cnumber" class="form-control"></span></div>
            <div><label for="Email">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email:&nbsp;</label>
            <span> <input type="hidden" id="Email" class="form-control"></span></div>
            <div><label for="Route">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Route:&nbsp;</label>
            <span> <input type="hidden" id="Route" class="form-control"></span></div>
            <div><label for="bustype">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Type of Bus:&nbsp;</label>
            <span> <input type="hidden" id="bustype" class="form-control"></span></div>
            <div><label for="Snumber">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Seat Number:&nbsp;</label>
            <span> <input type="hidden" id="Snumber" class="form-control"></span></div><br>
            <div class="container-fluid">
              <div><label for="Smart">Smart Padala Number:&nbsp;</label>
              <span> <input type="hidden" id="Smart" class="form-control"></span></div>
              <div><label for="Price">Price:&nbsp;</label>
              <span> <input type="hidden" id="Price" class="form-control"></span></div>
           </div>
        </div>
</body>
</html>