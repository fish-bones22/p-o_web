<?php
@ $db = mysqli_connect('127.0.0.1', 'root', '', 'po');

if (mysqli_connect_errno()) {
  echo "failed to connect to database";
  exit;
}

?>
