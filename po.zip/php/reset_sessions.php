<?php
  $_SESSION['uname'] = "";
  $_SESSION['error_signin'] = false;
  $_SESSION['admin'] = false;
  $_SESSION['admin_edit_success'] = 0;
  $_SESSION['email'] = '';
  $_SESSION['update_success'] = 0;
  $_SESSION['error_signup'] = false;
  $_SESSION['reserve_success'] = 0;
  $_SESSION['booking_cancel_success'] = 0;
 ?>
